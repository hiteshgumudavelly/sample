import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TelecomOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/sample","root","root");  
			Statement stmt=con.createStatement();  
			StringBuilder htmlBuilder = new StringBuilder();
			htmlBuilder.append("<html>");
			htmlBuilder.append("<head><title>Telecom Operator</title></head>");
			htmlBuilder.append("<body><td>Plan name</td>\r\n" +" <td><INPUT TYPE=\"text\" name=\"pname\" size=\"30\" maxlength=\"20\"></td>");
			htmlBuilder.append("Monthly rentals</td>\r\n" +"<td><INPUT TYPE=\"text\" name=\"mrentals\" size=\"30\" maxlength=\"20\"></td>");
			htmlBuilder.append("Free internet</td>\r\n" +"<td><INPUT TYPE=\"text\" name=\"freeint\" size=\"30\" maxlength=\"20\"></td>");
			htmlBuilder.append("Free calls</td>\r\n" +"<td><INPUT TYPE=\"text\" name=\"freecall\" size=\"30\" maxlength=\"20\"></td>");
			htmlBuilder.append("Free sms</td>\r\n" +"<td><INPUT TYPE=\"text\" name=\"freesms\" size=\"30\" maxlength=\"20\"></td>");
			htmlBuilder.append("call charges</td>\r\n" +"<td><INPUT TYPE=\"text\" name=\"callcrgs\" size=\"30\" maxlength=\"20\"></td>");
			htmlBuilder.append("Sms charges</td>\r\n" +"<td><INPUT TYPE=\"text\" name=\"smscrgs\" size=\"30\" maxlength=\"20\"></td>");
			htmlBuilder.append("Data charges</td>\r\n" +"<td><INPUT TYPE=\"text\" name=\"datacrgs\" size=\"30\" maxlength=\"20\"></td>");
			htmlBuilder.append("Roaming charges</td>\r\n" +"<td><INPUT TYPE=\"text\" name=\"roamingcrgs\" size=\"30\" maxlength=\"20\"></td>");
			
			htmlBuilder.append("</html>");
			
			ResultSet rs=stmt.executeQuery("select * from plans");
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)+"  "+rs.getString(6)+"  "+rs.getString(7)+"  "+rs.getString(8)+"  "+rs.getString(9));  
			con.close();  
			}
		catch(Exception e)
		{ 
			System.out.println(e);
		}  
		
		

	}

}
